CKEDITOR.plugins.setLang('vimeo', 'en',
{
  vimeo : 
  {
    title : "Embed Vimeo Video",
    button : "Add Vimeo Video",
    pasteMsg : "Please copy and paste the id the Vimeo video, which can be found in the URL of the video, EX. http://www.vimeo.com/<strong>4483342</strong>"
  }
});
