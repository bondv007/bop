<?php
App::uses('AppModel', 'Model');
/**
* Breed Model
*
* @project Best of Pedigree
* @since 13 June 2015
* @version Cake Php 2.3.8
* @author Vivek Sharma
*/
class Breed extends AppModel {
	
	public $useTable = 'breeds';
	var $filename_thumbs_arr = array('200x140');
	
		
}

?>
