<?php
App::uses('AppModel', 'Model');
/**
* Category Model
*
* @project Crossfit
* @since 7 August 2013
* @version Cake Php 2.3.8
* @author Bhanu Prakash Pandey
*/
class Aboutus extends AppModel {

	var $team_thumbs_arr = array('110x110', '267x223');
	var $sponsor_thumbs_arr = array('221x145');
	var $block_thumbs_arr = array('290x190');
	var $block_big_thumbs_arr = array('290x250');
}
