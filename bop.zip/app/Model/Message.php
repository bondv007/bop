<?php
App::uses('AppModel', 'Model');
/**
* Message Model
*
* @project Crossfit
* @since 30 June 2014
* @version Cake Php 2.3.8
* @author Vivek Sharma
*/
class Message extends AppModel {
	
	public $useTable = 'messages';
	
}
